run("cp /tmp/tmsh/tmsh.py /py/tmsh.py")
